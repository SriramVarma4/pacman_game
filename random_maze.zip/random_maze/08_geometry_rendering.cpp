/*This source code copyrighted by Lazy Foo' Productions (2004-2020)
and may not be redistributed without written permission.*/

//Using SDL, SDL_image, standard IO, math, and strings
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include<stdlib.h>
#include <string>
#include <cmath>
#include <time.h>
#include <vector>
using namespace std;

//Screen dimension constants
const int SCREEN_WIDTH = 1740;
const int SCREEN_HEIGHT = 840;

class rect_para{
public:
	int x, y, w, h;
	rect_para(int a, int b, int c, int d){
		x = a; y = b; w = c; h = d;
	}
};

//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Loads individual image as texture
SDL_Texture* loadTexture( std::string path );

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;

int Rand_0_5(void){
	double i = ((double) rand() / RAND_MAX);
	if( i<0.2){
		return 1;
	}else if(i<0.4){
		return 2;
	}else if(i<0.6){
		return 3;
	}else if(i<0.8){
		return 4;
	}else{return 5;}
}

bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//Nothing to load
	return success;
}

void close()
{
	//Destroy window	
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* loadTexture( std::string path )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}

int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{	
			
			//While application is running
			
				srand(time(0));
				//Clear screen
				SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0xFF );
				SDL_RenderClear( gRenderer );
				
				

				//SDL_Rect pacman_home = {1620}
				//Update screen

				vector<rect_para> rect_queue;
				int X= 60;int Y= 60; int H=0; int W=0;
				while(Y + 40<= 820){
					H = Rand_0_5()*40;
					W = Rand_0_5()*40;
					//printf("%i\n", Y + H+40);
						
					if (Y + H + 40 >= 820){
						H = 820 - 40 - Y;
						if (Y == 780){
							Y = Y-40;
							H = 40;
							//printf("%s\n","You Who" );
						}
						//printf("%i\n",H );
					}
					SDL_Rect block = {X, Y, W, H};
					SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
					SDL_RenderFillRect(gRenderer, &block);
					
					rect_para r(X,Y,W,H);
					rect_queue.push_back(r);
					SDL_RenderPresent(gRenderer);
					SDL_Delay(150);

					Y = Y + H + 40;
				}
				int no_vertical_blocks = rect_queue.size();

				for (int i =0 ; i<no_vertical_blocks ; i++){
					//vector<rect_para> hori_rect_que;
					Y = rect_queue[i].y;
					H = rect_queue[i].h;
					X = rect_queue[i].x + rect_queue[i].w + 40;
					while (X + 40 <= 1620){
						W = Rand_0_5()*40;
						if (X + W + 40 >= 1620){
							W = 1620 - 40 - X;
							if (X == 1580){
								X = X-40;
								W = 40;
							}
					
						}
					SDL_Rect block = {X, Y, W, H};
					SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
					SDL_RenderFillRect(gRenderer, &block);
					
					//rect_para r(X,Y,W,H);
					//rect_queue.push_back(r);
					SDL_RenderPresent(gRenderer);
					SDL_Delay(150);

					X = X + W + 40;
					}
				}
				for (int i =0 ; i<no_vertical_blocks+1; i++){
					for (int j =0; j<2; j++){
						if (j==0){
							X = (int)(((double)rand()/RAND_MAX)*12.5)*40 + 220;
						}
						else { X = (int)(((double)rand()/RAND_MAX)*17.5)*40 + 780;}
						Y = 20;
						if(i>0) {
							rect_para r = rect_queue[i-1];
							Y = r.y + r.h;
						}
						SDL_Rect block = {X, Y, 40, 40};
						SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
						SDL_RenderFillRect(gRenderer, &block);
						SDL_RenderPresent(gRenderer);
						SDL_Delay(150);
					}
				}
				SDL_Rect left_border = {0, 0, 20, 840};
				SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
				SDL_RenderFillRect(gRenderer, &left_border); 

				SDL_Rect right_border = {1620, 120, 20, 800};
				SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
				SDL_RenderFillRect(gRenderer, &right_border);

				SDL_Rect top_border = {20, 0, 1620, 20 };
				SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
				SDL_RenderFillRect(gRenderer, &top_border);

				SDL_Rect bottom_border = {20, 820, 1720, 20};
				SDL_SetRenderDrawColor(gRenderer, 0xBB, 0x00, 0x00, 0xFF);
				SDL_RenderFillRect(gRenderer, &bottom_border);
				
				SDL_Rect ghost_home = {1620, 0, 120, 120};
				SDL_SetRenderDrawColor(gRenderer, 0xBB, 0xBB, 0xBB, 0xFF);
				SDL_RenderFillRect(gRenderer, &ghost_home);
				SDL_RenderPresent(gRenderer);
			//SDL_Delay(10000);
		}
	}
	//Main loop flag
	bool quit = false;

	//Event handler
	SDL_Event e;
	while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
				}
	}

	//Free resources and close SDL
	close();

	return 0;
}